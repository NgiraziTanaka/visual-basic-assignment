﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAirline
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Labelwelcome = New System.Windows.Forms.Label()
        Me.LabelTitle = New System.Windows.Forms.Label()
        Me.LabelSurname = New System.Windows.Forms.Label()
        Me.LabelFirstName = New System.Windows.Forms.Label()
        Me.TextBoxSurname = New System.Windows.Forms.TextBox()
        Me.TextBoxFirstName = New System.Windows.Forms.TextBox()
        Me.LabelPhoneNumber = New System.Windows.Forms.Label()
        Me.LabelPassword = New System.Windows.Forms.Label()
        Me.TextBoxPhoneNumber = New System.Windows.Forms.TextBox()
        Me.TextBoxPassword = New System.Windows.Forms.TextBox()
        Me.LabelEmail = New System.Windows.Forms.Label()
        Me.TextBoxEmail = New System.Windows.Forms.TextBox()
        Me.GroupBoxGender = New System.Windows.Forms.GroupBox()
        Me.RadioButtonFemale = New System.Windows.Forms.RadioButton()
        Me.RadioButtonMale = New System.Windows.Forms.RadioButton()
        Me.LabelFlightDetails = New System.Windows.Forms.Label()
        Me.LabelFlightName = New System.Windows.Forms.Label()
        Me.ComboBoxFlightName = New System.Windows.Forms.ComboBox()
        Me.LabelCountryOfDept = New System.Windows.Forms.Label()
        Me.TextBoxCountryOfDept = New System.Windows.Forms.TextBox()
        Me.LabelCountryOfArr = New System.Windows.Forms.Label()
        Me.TextBoxCountryOfArr = New System.Windows.Forms.TextBox()
        Me.LabelDateOFDept = New System.Windows.Forms.Label()
        Me.DateTimePickerDepature = New System.Windows.Forms.DateTimePicker()
        Me.LabelDateOfReturn = New System.Windows.Forms.Label()
        Me.DateTimePickerReturn = New System.Windows.Forms.DateTimePicker()
        Me.LabelTicketType = New System.Windows.Forms.Label()
        Me.ComboBoxTicketType = New System.Windows.Forms.ComboBox()
        Me.LabelPassengers = New System.Windows.Forms.Label()
        Me.LabelInfants = New System.Windows.Forms.Label()
        Me.ComboBoxInfants = New System.Windows.Forms.ComboBox()
        Me.LabelChildren = New System.Windows.Forms.Label()
        Me.ComboBoxChildren = New System.Windows.Forms.ComboBox()
        Me.LabelAdults = New System.Windows.Forms.Label()
        Me.ComboBoxAdults = New System.Windows.Forms.ComboBox()
        Me.CheckBoxAgree = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ButtonTwitter = New System.Windows.Forms.Button()
        Me.ButtonSubmit = New System.Windows.Forms.Button()
        Me.ComboBoxTitle = New System.Windows.Forms.ComboBox()
        Me.GroupBoxGender.SuspendLayout()
        Me.SuspendLayout()
        '
        'Labelwelcome
        '
        Me.Labelwelcome.AutoSize = True
        Me.Labelwelcome.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Labelwelcome.ForeColor = System.Drawing.Color.Red
        Me.Labelwelcome.Location = New System.Drawing.Point(198, 9)
        Me.Labelwelcome.Name = "Labelwelcome"
        Me.Labelwelcome.Size = New System.Drawing.Size(312, 23)
        Me.Labelwelcome.TabIndex = 0
        Me.Labelwelcome.Text = "FILL UP THE TravelAfirca FORM"
        '
        'LabelTitle
        '
        Me.LabelTitle.AutoSize = True
        Me.LabelTitle.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.LabelTitle.Location = New System.Drawing.Point(13, 55)
        Me.LabelTitle.Name = "LabelTitle"
        Me.LabelTitle.Size = New System.Drawing.Size(27, 13)
        Me.LabelTitle.TabIndex = 1
        Me.LabelTitle.Text = "Tilte"
        '
        'LabelSurname
        '
        Me.LabelSurname.AutoSize = True
        Me.LabelSurname.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.LabelSurname.Location = New System.Drawing.Point(12, 80)
        Me.LabelSurname.Name = "LabelSurname"
        Me.LabelSurname.Size = New System.Drawing.Size(49, 13)
        Me.LabelSurname.TabIndex = 3
        Me.LabelSurname.Text = "Surname"
        '
        'LabelFirstName
        '
        Me.LabelFirstName.AutoSize = True
        Me.LabelFirstName.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelFirstName.Location = New System.Drawing.Point(12, 113)
        Me.LabelFirstName.Name = "LabelFirstName"
        Me.LabelFirstName.Size = New System.Drawing.Size(57, 13)
        Me.LabelFirstName.TabIndex = 4
        Me.LabelFirstName.Text = "First Name"
        '
        'TextBoxSurname
        '
        Me.TextBoxSurname.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TextBoxSurname.Location = New System.Drawing.Point(128, 73)
        Me.TextBoxSurname.Name = "TextBoxSurname"
        Me.TextBoxSurname.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxSurname.TabIndex = 5
        '
        'TextBoxFirstName
        '
        Me.TextBoxFirstName.Location = New System.Drawing.Point(128, 106)
        Me.TextBoxFirstName.Name = "TextBoxFirstName"
        Me.TextBoxFirstName.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxFirstName.TabIndex = 6
        '
        'LabelPhoneNumber
        '
        Me.LabelPhoneNumber.AutoSize = True
        Me.LabelPhoneNumber.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelPhoneNumber.Location = New System.Drawing.Point(13, 145)
        Me.LabelPhoneNumber.Name = "LabelPhoneNumber"
        Me.LabelPhoneNumber.Size = New System.Drawing.Size(78, 13)
        Me.LabelPhoneNumber.TabIndex = 7
        Me.LabelPhoneNumber.Text = "Phone Number"
        '
        'LabelPassword
        '
        Me.LabelPassword.AutoSize = True
        Me.LabelPassword.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelPassword.Location = New System.Drawing.Point(13, 172)
        Me.LabelPassword.Name = "LabelPassword"
        Me.LabelPassword.Size = New System.Drawing.Size(53, 13)
        Me.LabelPassword.TabIndex = 8
        Me.LabelPassword.Text = "Password"
        '
        'TextBoxPhoneNumber
        '
        Me.TextBoxPhoneNumber.Location = New System.Drawing.Point(128, 137)
        Me.TextBoxPhoneNumber.Name = "TextBoxPhoneNumber"
        Me.TextBoxPhoneNumber.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxPhoneNumber.TabIndex = 9
        '
        'TextBoxPassword
        '
        Me.TextBoxPassword.Location = New System.Drawing.Point(128, 165)
        Me.TextBoxPassword.Name = "TextBoxPassword"
        Me.TextBoxPassword.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxPassword.TabIndex = 10
        '
        'LabelEmail
        '
        Me.LabelEmail.AutoSize = True
        Me.LabelEmail.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelEmail.Location = New System.Drawing.Point(15, 203)
        Me.LabelEmail.Name = "LabelEmail"
        Me.LabelEmail.Size = New System.Drawing.Size(73, 13)
        Me.LabelEmail.TabIndex = 11
        Me.LabelEmail.Text = "Email Address"
        '
        'TextBoxEmail
        '
        Me.TextBoxEmail.ForeColor = System.Drawing.SystemColors.Menu
        Me.TextBoxEmail.Location = New System.Drawing.Point(128, 195)
        Me.TextBoxEmail.Name = "TextBoxEmail"
        Me.TextBoxEmail.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxEmail.TabIndex = 12
        '
        'GroupBoxGender
        '
        Me.GroupBoxGender.Controls.Add(Me.RadioButtonFemale)
        Me.GroupBoxGender.Controls.Add(Me.RadioButtonMale)
        Me.GroupBoxGender.ForeColor = System.Drawing.SystemColors.Highlight
        Me.GroupBoxGender.Location = New System.Drawing.Point(286, 158)
        Me.GroupBoxGender.Name = "GroupBoxGender"
        Me.GroupBoxGender.Size = New System.Drawing.Size(105, 58)
        Me.GroupBoxGender.TabIndex = 13
        Me.GroupBoxGender.TabStop = False
        Me.GroupBoxGender.Text = "GENDER"
        '
        'RadioButtonFemale
        '
        Me.RadioButtonFemale.AutoSize = True
        Me.RadioButtonFemale.Location = New System.Drawing.Point(6, 41)
        Me.RadioButtonFemale.Name = "RadioButtonFemale"
        Me.RadioButtonFemale.Size = New System.Drawing.Size(59, 17)
        Me.RadioButtonFemale.TabIndex = 1
        Me.RadioButtonFemale.TabStop = True
        Me.RadioButtonFemale.Text = "Female"
        Me.RadioButtonFemale.UseVisualStyleBackColor = True
        '
        'RadioButtonMale
        '
        Me.RadioButtonMale.AutoSize = True
        Me.RadioButtonMale.Location = New System.Drawing.Point(9, 18)
        Me.RadioButtonMale.Name = "RadioButtonMale"
        Me.RadioButtonMale.Size = New System.Drawing.Size(48, 17)
        Me.RadioButtonMale.TabIndex = 0
        Me.RadioButtonMale.TabStop = True
        Me.RadioButtonMale.Text = "Male"
        Me.RadioButtonMale.UseVisualStyleBackColor = True
        '
        'LabelFlightDetails
        '
        Me.LabelFlightDetails.AutoSize = True
        Me.LabelFlightDetails.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFlightDetails.Location = New System.Drawing.Point(80, 242)
        Me.LabelFlightDetails.Name = "LabelFlightDetails"
        Me.LabelFlightDetails.Size = New System.Drawing.Size(123, 16)
        Me.LabelFlightDetails.TabIndex = 14
        Me.LabelFlightDetails.Text = "*FLIGHT DETAILS*"
        '
        'LabelFlightName
        '
        Me.LabelFlightName.AutoSize = True
        Me.LabelFlightName.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelFlightName.Location = New System.Drawing.Point(16, 284)
        Me.LabelFlightName.Name = "LabelFlightName"
        Me.LabelFlightName.Size = New System.Drawing.Size(75, 13)
        Me.LabelFlightName.TabIndex = 15
        Me.LabelFlightName.Text = "Prefered Flight"
        '
        'ComboBoxFlightName
        '
        Me.ComboBoxFlightName.FormattingEnabled = True
        Me.ComboBoxFlightName.Items.AddRange(New Object() {"14DIAMONDS", "TN14", "FASTDIAMOND"})
        Me.ComboBoxFlightName.Location = New System.Drawing.Point(137, 276)
        Me.ComboBoxFlightName.Name = "ComboBoxFlightName"
        Me.ComboBoxFlightName.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxFlightName.TabIndex = 16
        '
        'LabelCountryOfDept
        '
        Me.LabelCountryOfDept.AutoSize = True
        Me.LabelCountryOfDept.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelCountryOfDept.Location = New System.Drawing.Point(16, 311)
        Me.LabelCountryOfDept.Name = "LabelCountryOfDept"
        Me.LabelCountryOfDept.Size = New System.Drawing.Size(104, 13)
        Me.LabelCountryOfDept.TabIndex = 17
        Me.LabelCountryOfDept.Text = "Country Of Depature"
        '
        'TextBoxCountryOfDept
        '
        Me.TextBoxCountryOfDept.Location = New System.Drawing.Point(137, 308)
        Me.TextBoxCountryOfDept.Name = "TextBoxCountryOfDept"
        Me.TextBoxCountryOfDept.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxCountryOfDept.TabIndex = 18
        '
        'LabelCountryOfArr
        '
        Me.LabelCountryOfArr.AutoSize = True
        Me.LabelCountryOfArr.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelCountryOfArr.Location = New System.Drawing.Point(16, 346)
        Me.LabelCountryOfArr.Name = "LabelCountryOfArr"
        Me.LabelCountryOfArr.Size = New System.Drawing.Size(89, 13)
        Me.LabelCountryOfArr.TabIndex = 19
        Me.LabelCountryOfArr.Text = "Country Of Arrival"
        '
        'TextBoxCountryOfArr
        '
        Me.TextBoxCountryOfArr.Location = New System.Drawing.Point(137, 346)
        Me.TextBoxCountryOfArr.Name = "TextBoxCountryOfArr"
        Me.TextBoxCountryOfArr.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxCountryOfArr.TabIndex = 20
        '
        'LabelDateOFDept
        '
        Me.LabelDateOFDept.AutoSize = True
        Me.LabelDateOFDept.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelDateOFDept.Location = New System.Drawing.Point(343, 312)
        Me.LabelDateOFDept.Name = "LabelDateOFDept"
        Me.LabelDateOFDept.Size = New System.Drawing.Size(91, 13)
        Me.LabelDateOFDept.TabIndex = 21
        Me.LabelDateOFDept.Text = "Date Of Depature"
        '
        'DateTimePickerDepature
        '
        Me.DateTimePickerDepature.Location = New System.Drawing.Point(454, 305)
        Me.DateTimePickerDepature.Name = "DateTimePickerDepature"
        Me.DateTimePickerDepature.Size = New System.Drawing.Size(180, 20)
        Me.DateTimePickerDepature.TabIndex = 22
        '
        'LabelDateOfReturn
        '
        Me.LabelDateOfReturn.AutoSize = True
        Me.LabelDateOfReturn.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelDateOfReturn.Location = New System.Drawing.Point(343, 346)
        Me.LabelDateOfReturn.Name = "LabelDateOfReturn"
        Me.LabelDateOfReturn.Size = New System.Drawing.Size(79, 13)
        Me.LabelDateOfReturn.TabIndex = 23
        Me.LabelDateOfReturn.Text = "Date Of Return"
        '
        'DateTimePickerReturn
        '
        Me.DateTimePickerReturn.Location = New System.Drawing.Point(454, 345)
        Me.DateTimePickerReturn.Name = "DateTimePickerReturn"
        Me.DateTimePickerReturn.Size = New System.Drawing.Size(180, 20)
        Me.DateTimePickerReturn.TabIndex = 24
        '
        'LabelTicketType
        '
        Me.LabelTicketType.AutoSize = True
        Me.LabelTicketType.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelTicketType.Location = New System.Drawing.Point(16, 382)
        Me.LabelTicketType.Name = "LabelTicketType"
        Me.LabelTicketType.Size = New System.Drawing.Size(64, 13)
        Me.LabelTicketType.TabIndex = 25
        Me.LabelTicketType.Text = "Ticket Type"
        '
        'ComboBoxTicketType
        '
        Me.ComboBoxTicketType.FormattingEnabled = True
        Me.ComboBoxTicketType.Items.AddRange(New Object() {"PLATINUM(first class)", "GOLD(business class)", "SILVER(economy class)"})
        Me.ComboBoxTicketType.Location = New System.Drawing.Point(137, 373)
        Me.ComboBoxTicketType.Name = "ComboBoxTicketType"
        Me.ComboBoxTicketType.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxTicketType.TabIndex = 26
        '
        'LabelPassengers
        '
        Me.LabelPassengers.AutoSize = True
        Me.LabelPassengers.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPassengers.Location = New System.Drawing.Point(80, 417)
        Me.LabelPassengers.Name = "LabelPassengers"
        Me.LabelPassengers.Size = New System.Drawing.Size(105, 16)
        Me.LabelPassengers.TabIndex = 27
        Me.LabelPassengers.Text = "*PASSENGERS*"
        '
        'LabelInfants
        '
        Me.LabelInfants.AutoSize = True
        Me.LabelInfants.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelInfants.Location = New System.Drawing.Point(25, 446)
        Me.LabelInfants.Name = "LabelInfants"
        Me.LabelInfants.Size = New System.Drawing.Size(156, 13)
        Me.LabelInfants.TabIndex = 28
        Me.LabelInfants.Text = "Number Of Infants On Your Trip"
        '
        'ComboBoxInfants
        '
        Me.ComboBoxInfants.FormattingEnabled = True
        Me.ComboBoxInfants.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5"})
        Me.ComboBoxInfants.Location = New System.Drawing.Point(251, 438)
        Me.ComboBoxInfants.Name = "ComboBoxInfants"
        Me.ComboBoxInfants.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxInfants.TabIndex = 29
        '
        'LabelChildren
        '
        Me.LabelChildren.AutoSize = True
        Me.LabelChildren.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelChildren.Location = New System.Drawing.Point(25, 484)
        Me.LabelChildren.Name = "LabelChildren"
        Me.LabelChildren.Size = New System.Drawing.Size(165, 13)
        Me.LabelChildren.TabIndex = 30
        Me.LabelChildren.Text = "Number Of Children  On Your Trip"
        '
        'ComboBoxChildren
        '
        Me.ComboBoxChildren.FormattingEnabled = True
        Me.ComboBoxChildren.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5"})
        Me.ComboBoxChildren.Location = New System.Drawing.Point(251, 476)
        Me.ComboBoxChildren.Name = "ComboBoxChildren"
        Me.ComboBoxChildren.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxChildren.TabIndex = 31
        '
        'LabelAdults
        '
        Me.LabelAdults.AutoSize = True
        Me.LabelAdults.ForeColor = System.Drawing.SystemColors.Highlight
        Me.LabelAdults.Location = New System.Drawing.Point(28, 518)
        Me.LabelAdults.Name = "LabelAdults"
        Me.LabelAdults.Size = New System.Drawing.Size(153, 13)
        Me.LabelAdults.TabIndex = 32
        Me.LabelAdults.Text = "Number Of Adults On Your Trip"
        '
        'ComboBoxAdults
        '
        Me.ComboBoxAdults.FormattingEnabled = True
        Me.ComboBoxAdults.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5"})
        Me.ComboBoxAdults.Location = New System.Drawing.Point(251, 510)
        Me.ComboBoxAdults.Name = "ComboBoxAdults"
        Me.ComboBoxAdults.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxAdults.TabIndex = 33
        '
        'CheckBoxAgree
        '
        Me.CheckBoxAgree.AutoSize = True
        Me.CheckBoxAgree.ForeColor = System.Drawing.Color.Red
        Me.CheckBoxAgree.Location = New System.Drawing.Point(251, 556)
        Me.CheckBoxAgree.Name = "CheckBoxAgree"
        Me.CheckBoxAgree.Size = New System.Drawing.Size(260, 17)
        Me.CheckBoxAgree.TabIndex = 34
        Me.CheckBoxAgree.Text = "l agree to the terms and conditions of TravelAfrica"
        Me.CheckBoxAgree.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Button1.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Button1.Location = New System.Drawing.Point(1, 655)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(79, 40)
        Me.Button1.TabIndex = 35
        Me.Button1.Text = "like us on facebook"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ButtonTwitter
        '
        Me.ButtonTwitter.ForeColor = System.Drawing.SystemColors.Highlight
        Me.ButtonTwitter.Location = New System.Drawing.Point(597, 655)
        Me.ButtonTwitter.Name = "ButtonTwitter"
        Me.ButtonTwitter.Size = New System.Drawing.Size(83, 40)
        Me.ButtonTwitter.TabIndex = 36
        Me.ButtonTwitter.Text = "follow us on twitter"
        Me.ButtonTwitter.UseVisualStyleBackColor = True
        '
        'ButtonSubmit
        '
        Me.ButtonSubmit.BackColor = System.Drawing.Color.Red
        Me.ButtonSubmit.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSubmit.ForeColor = System.Drawing.Color.White
        Me.ButtonSubmit.Location = New System.Drawing.Point(238, 605)
        Me.ButtonSubmit.Name = "ButtonSubmit"
        Me.ButtonSubmit.Size = New System.Drawing.Size(164, 61)
        Me.ButtonSubmit.TabIndex = 37
        Me.ButtonSubmit.Text = "SUBMIT"
        Me.ButtonSubmit.UseVisualStyleBackColor = False
        '
        'ComboBoxTitle
        '
        Me.ComboBoxTitle.FormattingEnabled = True
        Me.ComboBoxTitle.Items.AddRange(New Object() {"MR", "MRS"})
        Me.ComboBoxTitle.Location = New System.Drawing.Point(128, 46)
        Me.ComboBoxTitle.Name = "ComboBoxTitle"
        Me.ComboBoxTitle.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxTitle.TabIndex = 38
        '
        'FormAirline
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(692, 698)
        Me.Controls.Add(Me.ComboBoxTitle)
        Me.Controls.Add(Me.ButtonSubmit)
        Me.Controls.Add(Me.ButtonTwitter)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.CheckBoxAgree)
        Me.Controls.Add(Me.ComboBoxAdults)
        Me.Controls.Add(Me.LabelAdults)
        Me.Controls.Add(Me.ComboBoxChildren)
        Me.Controls.Add(Me.LabelChildren)
        Me.Controls.Add(Me.ComboBoxInfants)
        Me.Controls.Add(Me.LabelInfants)
        Me.Controls.Add(Me.LabelPassengers)
        Me.Controls.Add(Me.ComboBoxTicketType)
        Me.Controls.Add(Me.LabelTicketType)
        Me.Controls.Add(Me.DateTimePickerReturn)
        Me.Controls.Add(Me.LabelDateOfReturn)
        Me.Controls.Add(Me.DateTimePickerDepature)
        Me.Controls.Add(Me.LabelDateOFDept)
        Me.Controls.Add(Me.TextBoxCountryOfArr)
        Me.Controls.Add(Me.LabelCountryOfArr)
        Me.Controls.Add(Me.TextBoxCountryOfDept)
        Me.Controls.Add(Me.LabelCountryOfDept)
        Me.Controls.Add(Me.ComboBoxFlightName)
        Me.Controls.Add(Me.LabelFlightName)
        Me.Controls.Add(Me.LabelFlightDetails)
        Me.Controls.Add(Me.GroupBoxGender)
        Me.Controls.Add(Me.TextBoxEmail)
        Me.Controls.Add(Me.LabelEmail)
        Me.Controls.Add(Me.TextBoxPassword)
        Me.Controls.Add(Me.TextBoxPhoneNumber)
        Me.Controls.Add(Me.LabelPassword)
        Me.Controls.Add(Me.LabelPhoneNumber)
        Me.Controls.Add(Me.TextBoxFirstName)
        Me.Controls.Add(Me.TextBoxSurname)
        Me.Controls.Add(Me.LabelFirstName)
        Me.Controls.Add(Me.LabelSurname)
        Me.Controls.Add(Me.LabelTitle)
        Me.Controls.Add(Me.Labelwelcome)
        Me.Name = "FormAirline"
        Me.Text = "Airline Form"
        Me.GroupBoxGender.ResumeLayout(False)
        Me.GroupBoxGender.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Labelwelcome As System.Windows.Forms.Label
    Friend WithEvents LabelTitle As System.Windows.Forms.Label
    Friend WithEvents LabelSurname As System.Windows.Forms.Label
    Friend WithEvents LabelFirstName As System.Windows.Forms.Label
    Friend WithEvents TextBoxSurname As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxFirstName As System.Windows.Forms.TextBox
    Friend WithEvents LabelPhoneNumber As System.Windows.Forms.Label
    Friend WithEvents LabelPassword As System.Windows.Forms.Label
    Friend WithEvents TextBoxPhoneNumber As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxPassword As System.Windows.Forms.TextBox
    Friend WithEvents LabelEmail As System.Windows.Forms.Label
    Friend WithEvents TextBoxEmail As System.Windows.Forms.TextBox
    Friend WithEvents GroupBoxGender As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonFemale As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonMale As System.Windows.Forms.RadioButton
    Friend WithEvents LabelFlightDetails As System.Windows.Forms.Label
    Friend WithEvents LabelFlightName As System.Windows.Forms.Label
    Friend WithEvents ComboBoxFlightName As System.Windows.Forms.ComboBox
    Friend WithEvents LabelCountryOfDept As System.Windows.Forms.Label
    Friend WithEvents TextBoxCountryOfDept As System.Windows.Forms.TextBox
    Friend WithEvents LabelCountryOfArr As System.Windows.Forms.Label
    Friend WithEvents TextBoxCountryOfArr As System.Windows.Forms.TextBox
    Friend WithEvents LabelDateOFDept As System.Windows.Forms.Label
    Friend WithEvents DateTimePickerDepature As System.Windows.Forms.DateTimePicker
    Friend WithEvents LabelDateOfReturn As System.Windows.Forms.Label
    Friend WithEvents DateTimePickerReturn As System.Windows.Forms.DateTimePicker
    Friend WithEvents LabelTicketType As System.Windows.Forms.Label
    Friend WithEvents ComboBoxTicketType As System.Windows.Forms.ComboBox
    Friend WithEvents LabelPassengers As System.Windows.Forms.Label
    Friend WithEvents LabelInfants As System.Windows.Forms.Label
    Friend WithEvents ComboBoxInfants As System.Windows.Forms.ComboBox
    Friend WithEvents LabelChildren As System.Windows.Forms.Label
    Friend WithEvents ComboBoxChildren As System.Windows.Forms.ComboBox
    Friend WithEvents LabelAdults As System.Windows.Forms.Label
    Friend WithEvents ComboBoxAdults As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBoxAgree As System.Windows.Forms.CheckBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ButtonTwitter As System.Windows.Forms.Button
    Friend WithEvents ButtonSubmit As System.Windows.Forms.Button
    Friend WithEvents ComboBoxTitle As System.Windows.Forms.ComboBox
End Class
