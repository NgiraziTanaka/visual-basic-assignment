﻿Imports MySql.Data.MySqlClient

Public Class FormAirline
    Dim MysqlConn As MySqlConnection
    Dim COMMAND As MySqlCommand

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBoxFirstName.TextChanged

    End Sub

    Private Sub Labelwelcome_Click(sender As Object, e As EventArgs) Handles Labelwelcome.Click
        Me.Show()

    End Sub

    Private Sub ButtonSubmit_Click(sender As Object, e As EventArgs) Handles ButtonSubmit.Click



        If ComboBoxTitle.Text = "" Then
            MsgBox("title cannot be empty")
            ComboBoxTitle.Focus()

        End If


        If TextBoxSurname.Text = "" Then
            MsgBox("surname cannot be empty")
            TextBoxSurname.Focus()

        End If

        If TextBoxFirstName.Text = "" Then
            MsgBox("name cannot be empty")
            TextBoxFirstName.Focus()

        End If

        If TextBoxPhoneNumber.Text = "" Then
            MsgBox("phone number cannot be empty")
            TextBoxPhoneNumber.Focus()

        End If

        If TextBoxPassword.Text = "" Then
            MsgBox("password  cannot be empty")
            TextBoxPassword.Focus()

        End If

        If TextBoxEmail.Text = "" Then
            MsgBox("email cannot be empty")
            TextBoxEmail.Focus()

        End If

        If GroupBoxGender.Text = "" Then
            MsgBox("gender cannot be empty")
            GroupBoxGender.Focus()

        End If

        If ComboBoxFlightName.Text = "" Then
            MsgBox("flight cannot be empty")
            ComboBoxFlightName.Focus()

        End If

        If TextBoxCountryOfDept.Text = "" Then
            MsgBox("country of depature cannot be empty")
            TextBoxCountryOfDept.Focus()

        End If

        If TextBoxCountryOfArr.Text = "" Then
            MsgBox("country of arrival cannot be empty")
            TextBoxCountryOfArr.Focus()

        End If

        If DateTimePickerDepature.Text = "" Then
            MsgBox("date of depature cannot be empty")
            DateTimePickerDepature.Focus()

        End If


        If DateTimePickerReturn.Text = "" Then
            MsgBox("date of return cannot be empty")
            DateTimePickerReturn.Focus()

        End If

        If ComboBoxTicketType.Text = "" Then
            MsgBox("type of ticket cannot be empty")
            ComboBoxTicketType.Focus()

        End If

        If ComboBoxInfants.Text = "" Then
            MsgBox("number of infants cannot be empty")
            ComboBoxInfants.Focus()
        End If

        If ComboBoxChildren.Text = "" Then
            MsgBox("number of children cannot be empty")
            ComboBoxChildren.Focus()
        End If


        If ComboBoxAdults.Text = "" Then
            MsgBox("number of adults cannot be empty")
            ComboBoxAdults.Focus()
        End If

        If CheckBoxAgree.Text = "" Then
            MsgBox("sattus to travel africa cannot be empty")
            ComboBoxChildren.Focus()
        End If


        If RadioButtonMale.Checked = False And RadioButtonFemale.Checked = False Then
            MsgBox("Please check male or female")

        End If

        saveClient()








    End Sub



    Private Sub DateTimePickerDepature_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePickerDepature.ValueChanged

    End Sub
End Class