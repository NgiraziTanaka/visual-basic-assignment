﻿Imports System.Convert
Imports MySql.Data.MySqlClient

Module airlineModule
    Sub connection()
        Dim connectionstring As String
        Dim airlineConn As New MySqlConnection
        connectionstring = "server=localhost; userid=root; password=; database=sot_db"
        airlineConn.ConnectionString = connectionstring
        Try
            airlineConn.Open()

        Catch ex As MySqlException
            MsgBox(ex.Message)


        End Try
    End Sub

    Function airlineConnection() As MySqlConnection
        Dim connectionstring As String
        Dim airlineConn As New MySqlConnection
        connectionstring = "server=localhost; userid=root; password=; database=sot_db"

        Try
            airlineConn.Open()
            MsgBox("connected")
        Catch ex As MySqlException
            MsgBox(ex.Message)


        End Try
        Return airlineConn


    End Function

    Sub saveClient()
        Dim title As String
        Dim surname As String
        Dim firstName As String
        Dim phoneNumber As Integer
        Dim password As String
        Dim email As String
        Dim gender As String
        Dim preferedFlight As Decimal
        Dim countryOfDepature As String
        Dim countryOfArrival As String
        Dim dateOfDepature As Date
        Dim dateOfReturn As Date
        Dim ticketType As String
        Dim numberOfInfantsOnYourTrip As Integer
        Dim numberOfChildrenOnYourTrip As Integer
        Dim numberOfAdultsOnYourTrip As Integer
        Dim statusToTravelAfrica As Boolean

        Dim cmd As MySqlCommand
        Dim sqlString As String
        With FormAirline


            surname = .TextBoxSurname.Text
            firstName = .TextBoxFirstName.Text
            phoneNumber = .TextBoxPhoneNumber.Text
            password = .TextBoxPassword.Text
            email = .TextBoxEmail.Text
            preferedFlight = .ComboBoxFlightName.Text
            countryOfDepature = .TextBoxCountryOfDept.Text
            countryOfArrival = .TextBoxCountryOfArr.Text
            DateOfDepature = .DateTimePickerDepature.Text
            DateOfReturn = .DateTimePickerReturn.Text
            ticketType = .ComboBoxTicketType.Text
            NumberOfInfantsOnYourTrip = .ComboBoxInfants.Text
            NumberOfChildrenOnYourTrip = .ComboBoxChildren.Text
            NumberOfAdultsOnYourTrip = .ComboBoxAdults.Text
            title = .ComboBoxTitle.Text
            statusToTravelAfrica = False

           

            If .RadioButtonMale.Checked = False And .RadioButtonFemale.Checked = False Then
                MsgBox("Please check male or female")
            ElseIf .RadioButtonFemale.Checked = True Then
                gender = "female"
            ElseIf .RadioButtonMale.Checked = True Then
                gender = "male"
            End If

        End With

        sqlString = " INSERT INTO clients VALUES (('" & title & "', '" & surname & "', '" & firstName & "','" & phoneNumber & "','" & password & "','" & email & "','" & gender & "','" & preferedFlight & "','" & countryOfDepature & "','" & countryOfArrival & "','" & dateOfDepature & "','" & dateOfReturn & "','" & ticketType & "','" & numberOfAdultsOnYourTrip & "','" & numberOfChildrenOnYourTrip & "','" & numberOfAdultsOnYourTrip & "','" & statusToTravelAfrica & "')"



        With cmd


            .Connection = airlineConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            .ExecuteNonQuery()

        End With
        MsgBox("client saved")

    End Sub

End Module
