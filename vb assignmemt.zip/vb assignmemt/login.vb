﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Dim MysqlConn As MySqlConnection
    Dim COMMAND As MySqlCommand
    Dim READER As MySqlDataReader

    Private Sub ButtonCheckDBconnection_Click(sender As Object, e As EventArgs) Handles ButtonCheckDBconnection.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString =
            "server=localhost; userid=root; password=; database=sot_db"

        Try
            MysqlConn.Open()
            MessageBox.Show("you are connected to the DATABASE")
            MysqlConn.Close()


        Catch ex As MySqlException
            MessageBox.Show(ex.Message)

        End Try
        MysqlConn.Dispose()

    End Sub

    Private Sub ButtonSubmit_Click(sender As Object, e As EventArgs) Handles ButtonSubmit.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString =
            "server=localhost; userid=root; password=;  database=sot_db"
        Dim READER As MySqlDataReader

        

        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "select * from sot_db.admin where username='" & TextBoxUsername.Text & "' and password='" & TextBoxPassword.Text & "'"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            READER = COMMAND.ExecuteReader
            Dim count As Integer
            count = 0
            While READER.Read
                count = count + 1
            End While

            If count = 1 Then
                MessageBox.Show("SUCCESS, your credentials are correct")
                FormAirline.Show()
                Me.Hide()

            ElseIf count > 1 Then
                MessageBox.Show("Password and Username are duplicated")
            Else
                MessageBox.Show("SORRY, your credentials are wrong")

            End If

            MysqlConn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)

        End Try
       
    End Sub

End Class
